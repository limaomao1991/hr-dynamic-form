/**
 * HR Dynamic Form Renderer + Rule Engine (Frontend)
 * Covers: dynamic fields, repeater add/remove, visibleWhen/requiredWhen,
 * dirty/loading state, field & form errors, server validation errors,
 * cycle-safe rule evaluation.
 */

const API = window.location.origin.includes('3000')
  ? ''
  : (window.API_BASE || 'http://127.0.0.1:3000');

const FORM_ID = 'tech_onboarding';

// ---------- State ----------
let schemaRecord = null;
let formState = {};
let fieldErrors = {};
let formError = null;
let isDirty = false;
let isLoading = false;
let ruleMessages = {};

// ---------- Utils ----------
function $(sel) { return document.querySelector(sel); }
function $all(sel) { return [...document.querySelectorAll(sel)]; }

function getByPath(obj, path) {
  return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

function evalCondition(cond, data) {
  if (!cond) return true;
  const actual = getByPath(data, cond.field);
  switch (cond.operator) {
    case 'eq': return actual === cond.value;
    case 'neq': return actual !== cond.value;
    case 'gt': return Number(actual) > Number(cond.value);
    case 'gte': return Number(actual) >= Number(cond.value);
    case 'lt': return Number(actual) < Number(cond.value);
    case 'lte': return Number(actual) <= Number(cond.value);
    case 'in': return Array.isArray(cond.value) && cond.value.includes(actual);
    default: return true;
  }
}

function isVisible(field) {
  if (field.deprecated) return false;
  if (!field.visibleWhen) return true;
  return evalCondition(field.visibleWhen, formState);
}

function isRequired(field) {
  if (field.requiredWhen) return evalCondition(field.requiredWhen, formState);
  return !!field.required;
}

/**
 * Rule Engine (frontend) - cycle safe
 * Max iterations + visited keys prevent A→B→C→A loops
 */
function runRules(maxIter = 15) {
  const rules = schemaRecord?.schema?.rules || [];
  let changed = true;
  let iter = 0;
  const visited = new Set();
  ruleMessages = {};

  while (changed && iter < maxIter) {
    changed = false;
    iter++;
    for (const rule of rules) {
      const key = `${rule.id}@${iter}`;
      if (visited.has(key)) continue;
      if (!evalCondition(rule.when, formState)) continue;
      visited.add(key);
      for (const act of rule.actions || []) {
        if (act.type === 'setValue' && act.target != null) {
          if (formState[act.target] !== act.value) {
            formState[act.target] = act.value;
            changed = true;
          }
        }
        if (act.type === 'setMessage' && act.target) {
          ruleMessages[act.target] = act.value;
        }
      }
    }
  }
  if (iter >= maxIter) console.warn('[RuleEngine] max iterations, possible cycle');
}

// ---------- Renderer ----------
function renderForm() {
  const form = $('#dynamic-form');
  if (!schemaRecord) {
    form.innerHTML = '<p>Schema 加载失败</p>';
    return;
  }

  const schema = schemaRecord.schema;
  $('#form-title').textContent = schema.title || schema.formId;
  $('#form-version').textContent = `v${schemaRecord.version} · ${schemaRecord.status}`;

  form.innerHTML = '';
  (schema.fields || []).forEach(field => {
    form.appendChild(renderField(field));
  });

  applyVisibility();
}

function renderField(field, namePrefix = '') {
  const key = namePrefix ? `${namePrefix}.${field.key}` : field.key;
  const wrap = document.createElement('div');
  wrap.className = 'field';
  wrap.dataset.key = field.key;
  wrap.dataset.fullKey = key;

  if (field.type === 'alert') {
    wrap.className = 'alert field';
    wrap.dataset.key = field.key;
    wrap.textContent = field.ui?.message || field.label || '';
    wrap.style.display = isVisible(field) ? 'block' : 'none';
    return wrap;
  }

  if (field.type === 'object' && field.fields) {
    const legend = document.createElement('label');
    legend.textContent = field.label || field.key;
    wrap.appendChild(legend);
    const box = document.createElement('div');
    box.style.paddingLeft = '0.75rem';
    box.style.borderLeft = '2px solid var(--border)';
    if (!formState[field.key] || typeof formState[field.key] !== 'object') {
      formState[field.key] = {};
    }
    field.fields.forEach(f => {
      box.appendChild(renderField(f, key));
    });
    wrap.appendChild(box);
    return wrap;
  }

  if (field.type === 'repeater') {
    return renderRepeater(field, key, wrap);
  }

  const label = document.createElement('label');
  label.innerHTML = `${field.label || field.key}<span class="req" data-req="${field.key}" style="display:${isRequired(field) ? 'inline' : 'none'}">*</span>`;
  wrap.appendChild(label);

  let input;
  if (field.type === 'select') {
    input = document.createElement('select');
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = '请选择';
    input.appendChild(empty);
    (field.options || []).forEach(opt => {
      const o = document.createElement('option');
      o.value = String(opt.value);
      o.textContent = opt.label;
      // boolean handling
      if (formState[field.key] === opt.value || String(formState[field.key]) === String(opt.value)) {
        o.selected = true;
      }
      input.appendChild(o);
    });
  } else if (field.type === 'upload') {
    input = document.createElement('input');
    input.type = 'file';
    input.accept = (field.accept || []).join(',');
    // show current fileId if any
    if (formState[field.key]) {
      const info = document.createElement('div');
      info.className = 'field-error';
      info.style.color = 'var(--success)';
      info.textContent = `已上传: ${typeof formState[field.key] === 'object' ? formState[field.key].name || formState[field.key].fileId : formState[field.key]}`;
      wrap.appendChild(info);
    }
  } else {
    input = document.createElement('input');
    input.type = field.dataType === 'number' ? 'number' : field.dataType === 'date' ? 'date' : 'text';
    input.placeholder = field.placeholder || '';
    if (formState[field.key] != null) input.value = formState[field.key];
  }

  input.dataset.key = field.key;
  input.addEventListener('input', () => onFieldChange(field, input));
  input.addEventListener('change', () => onFieldChange(field, input));
  wrap.appendChild(input);

  const err = document.createElement('div');
  err.className = 'field-error';
  err.dataset.errorFor = field.key;
  if (fieldErrors[field.key]) err.textContent = fieldErrors[field.key];
  wrap.appendChild(err);

  return wrap;
}

function renderRepeater(field, key, wrap) {
  const label = document.createElement('label');
  label.textContent = field.label || field.key;
  wrap.appendChild(label);

  if (!Array.isArray(formState[field.key])) formState[field.key] = [];

  const box = document.createElement('div');
  box.className = 'repeater';
  box.dataset.repeater = field.key;

  formState[field.key].forEach((item, idx) => {
    box.appendChild(createRepeaterItem(field, idx));
  });

  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'btn btn-secondary btn-sm add-item';
  addBtn.textContent = '+ 添加一项';
  addBtn.onclick = () => {
    formState[field.key].push({});
    isDirty = true;
    renderForm();
  };
  box.appendChild(addBtn);
  wrap.appendChild(box);
  return wrap;
}

function createRepeaterItem(field, idx) {
  const item = document.createElement('div');
  item.className = 'repeater-item';
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'remove-item';
  remove.textContent = '×';
  remove.onclick = () => {
    formState[field.key].splice(idx, 1);
    isDirty = true;
    renderForm();
  };
  item.appendChild(remove);

  const itemFields = field.itemSchema?.fields || [];
  itemFields.forEach(f => {
    const subKey = `${field.key}[${idx}].${f.key}`;
    const row = document.createElement('div');
    row.className = 'field';
    const lab = document.createElement('label');
    lab.textContent = f.label || f.key;
    row.appendChild(lab);
    const input = document.createElement('input');
    input.type = f.dataType === 'date' ? 'date' : 'text';
    input.value = formState[field.key][idx]?.[f.key] ?? '';
    input.addEventListener('input', () => {
      if (!formState[field.key][idx]) formState[field.key][idx] = {};
      formState[field.key][idx][f.key] = input.value;
      isDirty = true;
      updateDirtyUI();
    });
    row.appendChild(input);
    item.appendChild(row);
  });
  return item;
}

function onFieldChange(field, input) {
  let val = input.value;
  if (field.type === 'select' && (field.dataType === 'boolean' || field.options?.some(o => typeof o.value === 'boolean'))) {
    if (val === 'true') val = true;
    else if (val === 'false') val = false;
    else if (val === '') val = undefined;
  }
  if (field.dataType === 'number' && val !== '') val = Number(val);
  if (field.type === 'upload' && input.files?.[0]) {
    uploadFile(input.files[0], field.key);
    return;
  }
  formState[field.key] = val;
  isDirty = true;
  fieldErrors[field.key] = '';
  runRules();
  applyVisibility();
  updateDirtyUI();
  // clear error display
  const errEl = document.querySelector(`[data-error-for="${field.key}"]`);
  if (errEl) errEl.textContent = '';
  input.classList.remove('error');
}

async function uploadFile(file, fieldKey) {
  const fd = new FormData();
  fd.append('file', file);
  try {
    const res = await fetch(`${API}/api/v1/files/upload`, { method: 'POST', body: fd, headers: { 'X-Actor': 'web-user' } });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'upload failed');
    formState[fieldKey] = { fileId: data.fileId, name: data.name, size: data.size };
    isDirty = true;
    renderForm();
  } catch (e) {
    fieldErrors[fieldKey] = e.message;
    renderForm();
  }
}

function applyVisibility() {
  $all('.field[data-key]').forEach(el => {
    const key = el.dataset.key;
    const field = (schemaRecord?.schema?.fields || []).find(f => f.key === key);
    if (!field) return;
    const visible = isVisible(field);
    el.style.display = visible ? '' : 'none';
    if (field.type === 'alert') {
      el.textContent = ruleMessages[key] || field.ui?.message || field.label || '';
    }
    // required star
    const reqSpan = el.querySelector(`[data-req="${key}"]`);
    if (reqSpan) reqSpan.style.display = isRequired(field) ? 'inline' : 'none';
  });
}

function updateDirtyUI() {
  const title = $('#form-title');
  if (isDirty && !title.querySelector('.dirty-dot')) {
    const dot = document.createElement('span');
    dot.className = 'dirty-dot';
    title.appendChild(dot);
  }
  if (!isDirty) title.querySelector('.dirty-dot')?.remove();
}

function setLoading(v) {
  isLoading = v;
  const btn = $('#btn-submit');
  btn.disabled = v;
  btn.querySelector('.btn-text').classList.toggle('hidden', v);
  btn.querySelector('.btn-loading').classList.toggle('hidden', !v);
}

function showFormErrors(errors) {
  fieldErrors = {};
  (errors || []).forEach(e => {
    const key = e.path.split('[')[0].split('.')[0];
    fieldErrors[key] = e.message;
  });
  const box = $('#form-errors');
  if (errors?.length) {
    box.textContent = errors.map(e => `${e.path}: ${e.message}`).join('\n');
    box.classList.remove('hidden');
  } else {
    box.classList.add('hidden');
  }
  // mark inputs
  $all('[data-key]').forEach(input => {
    if (input.tagName === 'INPUT' || input.tagName === 'SELECT') {
      input.classList.toggle('error', !!fieldErrors[input.dataset.key]);
    }
  });
  $all('[data-error-for]').forEach(el => {
    el.textContent = fieldErrors[el.dataset.errorFor] || '';
  });
}

function initDefaults() {
  const fields = schemaRecord?.schema?.fields || [];
  fields.forEach(f => {
    if (formState[f.key] === undefined && f.defaultValue !== undefined) {
      formState[f.key] = f.defaultValue;
    }
    if (f.type === 'repeater' && formState[f.key] === undefined) {
      formState[f.key] = [];
    }
  });
}

// ---------- API ----------
async function loadSchema() {
  const res = await fetch(`${API}/api/v1/schemas/${FORM_ID}`);
  if (!res.ok) throw new Error('加载 Schema 失败');
  schemaRecord = await res.json();
  formState = {};
  initDefaults();
  runRules();
  renderForm();
}

async function submitForm() {
  setLoading(true);
  showFormErrors([]);
  $('#submit-result').classList.add('hidden');
  try {
    const res = await fetch(`${API}/api/v1/dynamic-data/${FORM_ID}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Actor': 'web-user' },
      body: JSON.stringify(formState)
    });
    const data = await res.json();
    if (!res.ok) {
      if (data.errors) showFormErrors(data.errors);
      else throw new Error(data.message || data.error);
      return;
    }
    isDirty = false;
    updateDirtyUI();
    const result = $('#submit-result');
    result.classList.remove('hidden');
    result.textContent = `提交成功！ID=${data.id}\nHooks: ${JSON.stringify(data.meta, null, 2)}`;
  } catch (e) {
    showFormErrors([{ path: '_form', message: e.message }]);
  } finally {
    setLoading(false);
  }
}

async function loadList(filter) {
  let url = `${API}/api/v1/dynamic-data/${FORM_ID}?page=1&pageSize=50`;
  if (filter) url += `&filter=${encodeURIComponent(filter)}`;
  const res = await fetch(url);
  const data = await res.json();
  const box = $('#list-container');
  if (!data.items?.length) {
    box.innerHTML = '<p style="color:var(--muted)">暂无数据</p>';
    return;
  }
  box.innerHTML = data.items.map(item => `
    <div class="list-item">
      <div>
        <strong>${item.data.fullName || '(无姓名)'}</strong>
        · ${item.data.email || ''}
        · 薪资 ${item.data.expectedSalary ?? '-'}
        <div class="meta">ID ${item.id} · Schema v${item.schemaVersion} · ${item.createdAt}</div>
      </div>
      <div class="meta">${item.createdBy}</div>
    </div>
  `).join('');
}

async function loadVersions() {
  const res = await fetch(`${API}/api/v1/schemas/${FORM_ID}/versions`);
  const data = await res.json();
  $('#schema-versions').innerHTML = (data.versions || []).map(v => `
    <div class="version-row">
      <span>v${v.version}</span>
      <span class="status ${v.status}">${v.status}</span>
      <span>${v.title}</span>
      <span style="color:var(--muted);font-size:0.8rem">${v.published_at || v.updated_at || ''}</span>
    </div>
  `).join('');

  // load latest for editor (prefer draft)
  const draft = data.versions?.find(v => v.status === 'draft');
  const targetVer = draft?.version || data.versions?.[0]?.version;
  if (targetVer) {
    const s = await fetch(`${API}/api/v1/schemas/${FORM_ID}/versions/${targetVer}`).then(r => r.json());
    $('#schema-json').value = JSON.stringify({
      title: s.title,
      description: s.description,
      fields: s.schema.fields,
      rules: s.schema.rules,
      expectedVersion: s.version
    }, null, 2);
  }
}

async function saveSchema() {
  const msg = $('#schema-save-msg');
  msg.textContent = '';
  try {
    const body = JSON.parse($('#schema-json').value);
    const res = await fetch(`${API}/api/v1/schemas/${FORM_ID}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-Actor': 'hr-editor', 'If-Match': String(body.expectedVersion || '') },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (res.status === 409) {
      msg.textContent = '冲突！其他用户已修改，请刷新后重试';
      msg.style.color = 'var(--danger)';
      console.log('current', data.current);
      return;
    }
    if (!res.ok) throw new Error(data.message || data.error);
    msg.textContent = `已保存 draft v${data.version}`;
    msg.style.color = 'var(--success)';
    loadVersions();
  } catch (e) {
    msg.textContent = e.message;
    msg.style.color = 'var(--danger)';
  }
}

async function publishSchema() {
  const res = await fetch(`${API}/api/v1/schemas/${FORM_ID}/publish`, {
    method: 'POST',
    headers: { 'X-Actor': 'hr-publisher' }
  });
  const data = await res.json();
  if (!res.ok) {
    alert(data.message || data.error);
    return;
  }
  alert(`已发布 v${data.version}`);
  loadVersions();
  loadSchema();
}

async function loadAudit() {
  const [schemaLogs, subLogs] = await Promise.all([
    fetch(`${API}/api/v1/schemas/${FORM_ID}/audit`).then(r => r.json()),
    fetch(`${API}/api/v1/dynamic-data/${FORM_ID}/1/audit`).then(r => r.json()).catch(() => ({ logs: [] }))
  ]);
  const all = [...(schemaLogs.logs || []), ...(subLogs.logs || [])]
    .sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''));
  $('#audit-container').innerHTML = all.length ? all.map(l => `
    <div class="audit-row">
      <strong>${l.action}</strong> · ${l.entity_type} ${l.entity_id}
      <span style="color:var(--muted)"> by ${l.actor} · ${l.created_at}</span>
      ${l.diff ? `<div class="diff">${JSON.stringify(l.diff, null, 2)}</div>` : ''}
    </div>
  `).join('') : '<p style="color:var(--muted)">暂无审计记录</p>';
}

// ---------- Tabs & Events ----------
function initTabs() {
  $all('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      $all('.tab').forEach(t => t.classList.remove('active'));
      $all('.panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      $(`#panel-${tab.dataset.tab}`).classList.add('active');
      if (tab.dataset.tab === 'list') loadList($('#filter-input').value);
      if (tab.dataset.tab === 'schema') loadVersions();
      if (tab.dataset.tab === 'audit') loadAudit();
    });
  });
}

function init() {
  initTabs();
  $('#btn-submit').onclick = submitForm;
  $('#btn-reset').onclick = () => {
    formState = {};
    initDefaults();
    isDirty = false;
    fieldErrors = {};
    showFormErrors([]);
    renderForm();
    updateDirtyUI();
  };
  $('#btn-filter').onclick = () => loadList($('#filter-input').value);
  $('#btn-save-schema').onclick = saveSchema;
  $('#btn-publish').onclick = publishSchema;

  loadSchema().catch(e => {
    $('#form-title').textContent = '加载失败: ' + e.message;
  });
}

init();
