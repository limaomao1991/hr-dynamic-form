# HR Dynamic Form System - Schema & Architecture Design

## 1. JSON Schema Structure (Q0)

```json
{
  "formId": "tech_onboarding",
  "title": "技术岗入职信息表",
  "description": "技术岗位入职信息收集",
  "version": 3,
  "status": "published",          // draft | published | archived
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-06-01T00:00:00Z",
  "publishedAt": "2025-06-01T00:00:00Z",
  "fields": [
    {
      "key": "fullName",
      "label": "姓名",
      "type": "input",
      "dataType": "string",
      "required": true,
      "defaultValue": null,
      "placeholder": "请输入真实姓名",
      "validation": {
        "minLength": 2,
        "maxLength": 50,
        "pattern": "^[\\u4e00-\\u9fa5a-zA-Z\\s]+$"
      },
      "deprecated": false,
      "deprecatedSince": null,
      "ui": {
        "colSpan": 12,
        "order": 1
      }
    },
    {
      "key": "email",
      "label": "邮箱",
      "type": "input",
      "dataType": "email",
      "required": true,
      "validation": {
        "format": "email"
      }
    },
    {
      "key": "isFreshGraduate",
      "label": "是否应届生",
      "type": "select",
      "dataType": "boolean",
      "required": true,
      "options": [
        { "label": "是", "value": true },
        { "label": "否", "value": false }
      ],
      "defaultValue": false
    },
    {
      "key": "previousCompany",
      "label": "前公司名称",
      "type": "input",
      "dataType": "string",
      "required": true,
      "visibleWhen": {
        "field": "isFreshGraduate",
        "operator": "eq",
        "value": false
      },
      "requiredWhen": {
        "field": "isFreshGraduate",
        "operator": "eq",
        "value": false
      }
    },
    {
      "key": "expectedSalary",
      "label": "期望薪资",
      "type": "input",
      "dataType": "number",
      "required": true,
      "validation": {
        "min": 0,
        "max": 500000
      }
    },
    {
      "key": "needHrbpApproval",
      "label": "需要 HRBP 特别审批",
      "type": "alert",
      "dataType": "null",
      "visibleWhen": {
        "field": "expectedSalary",
        "operator": "gt",
        "value": 30000
      },
      "ui": {
        "variant": "warning",
        "message": "期望薪资超过 30000，需要 HRBP 特别审批"
      }
    },
    {
      "key": "workExperience",
      "label": "工作履历",
      "type": "repeater",
      "dataType": "array",
      "minItems": 0,
      "maxItems": 20,
      "itemSchema": {
        "type": "object",
        "fields": [
          {
            "key": "company",
            "label": "公司名称",
            "type": "input",
            "required": true
          },
          {
            "key": "position",
            "label": "职位",
            "type": "input",
            "required": true
          },
          {
            "key": "startDate",
            "label": "开始时间",
            "type": "input",
            "dataType": "date",
            "required": true
          },
          {
            "key": "endDate",
            "label": "结束时间",
            "type": "input",
            "dataType": "date"
          }
        ]
      }
    },
    {
      "key": "resume",
      "label": "简历",
      "type": "upload",
      "dataType": "file",
      "required": true,
      "accept": [".pdf", ".doc", ".docx"],
      "maxSizeMB": 10
    },
    {
      "key": "address",
      "label": "联系地址",
      "type": "object",
      "fields": [
        { "key": "province", "label": "省", "type": "input", "required": true },
        { "key": "city", "label": "市", "type": "input", "required": true },
        { "key": "detail", "label": "详细地址", "type": "input", "required": true }
      ]
    }
  ],
  "rules": [
    {
      "id": "rule_salary_alert",
      "when": { "field": "expectedSalary", "operator": "gt", "value": 30000 },
      "actions": [
        { "type": "show", "target": "needHrbpApproval" },
        { "type": "setMessage", "target": "needHrbpApproval", "value": "需要 HRBP 特别审批" }
      ]
    }
  ]
}
```

### 关键设计决策

| 需求 | 方案 |
|------|------|
| 嵌套 Object | `type: "object"` + `fields` 数组 |
| 嵌套 Array | `type: "repeater"` + `itemSchema` |
| 字段默认值 | `defaultValue` |
| Schema Version | 顶层 `version` 整数，发布时递增 |
| 字段废弃 | `deprecated: true` + `deprecatedSince`，渲染时隐藏但历史数据可读 |
| 条件显隐/必填 | `visibleWhen` / `requiredWhen` 表达式 |
| 防循环 Rule Engine | 使用拓扑排序 + 执行次数上限 + 已执行规则集合 |

## 2. 数据模型（数据库）

### schemas 表
- id, form_id, version, status (draft/published/archived)
- title, description, schema_json (完整 Schema)
- created_by, created_at, updated_at, published_at
- UNIQUE(form_id, version)

### submissions 表
- id, form_id, schema_version (锁定提交时的版本)
- data_json (业务数据，不含大文件二进制)
- created_by, created_at, updated_at
- status (draft/submitted)

### files 表
- id, submission_id (可空，先上传后关联), original_name, mime_type
- size, storage_path (本地或 S3 key), hash, uploaded_by, created_at

### audit_logs 表
- id, entity_type (schema/submission), entity_id
- action, actor, before_json, after_json, diff_json
- created_at

### schema_locks / version 乐观锁
- 使用 schema.version 做 Optimistic Locking

## 3. API 设计

- `POST   /api/v1/schemas`                    创建 draft
- `PUT    /api/v1/schemas/:formId`            更新 draft（乐观锁）
- `POST   /api/v1/schemas/:formId/publish`    发布 → 生成新 version
- `GET    /api/v1/schemas/:formId`            获取最新 published
- `GET    /api/v1/schemas/:formId/versions`   历史版本列表
- `GET    /api/v1/schemas/:formId/versions/:v` 指定版本

- `POST   /api/v1/dynamic-data/:formId`       提交（校验 + 持久化）
- `GET    /api/v1/dynamic-data/:formId`       查询 + 动态筛选 + 分页
- `GET    /api/v1/dynamic-data/:formId/:id`   单条
- `PATCH  /api/v1/dynamic-data/:formId/:id`  更新（带审计）

- `POST   /api/v1/files/upload`               文件上传（返回 fileId）
- `GET    /api/v1/files/:id`                  下载/预览

## 4. 并发控制 (Q5)

Form Builder 保存时携带 `If-Match: <version>` 或 body 中的 `expectedVersion`。
服务端比较，不一致返回 409 Conflict + 最新 version。

## 5. 钩子机制 (Q4)

```ts
type HookPoint = 'beforeValidate' | 'afterValidate' | 'beforeSave' | 'afterSave' | 'onError';

interface Plugin {
  name: string;
  hooks: Partial<Record<HookPoint, (ctx: HookContext) => Promise<void> | void>>;
}
```

内置示例：钉钉通知、生成 PDF、同步考勤系统（mock）。

## 6. 文件上传安全 (Q3)

1. 前端先调 `/files/upload` 拿到 `fileId` + 临时 URL
2. Submission 的 upload 字段只存 `fileId`（或 `{ fileId, name, size }`）
3. 服务端校验 mime、大小、病毒扫描（可扩展）
4. 存储走本地 uploads/ 或对象存储，永不进 submissions.data_json
