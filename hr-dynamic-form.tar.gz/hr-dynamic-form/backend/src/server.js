import http from 'node:http';
import { URL } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  getLatestPublished,
  getSchemaByVersion,
  listVersions,
  createOrUpdateDraft,
  publish,
  getAuditLogs
} from './schemaService.js';
import {
  createSubmission,
  querySubmissions,
  getSubmission,
  updateSubmission
} from './submissionService.js';
import { saveUploadedFile, getFileMeta, getFilePath } from './fileService.js';
import './hooks.js'; // register plugins

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

// ---------- helpers ----------
function send(res, status, data, headers = {}) {
  const body = JSON.stringify(data, null, 0);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, If-Match, X-Actor',
    ...headers
  });
  res.end(body);
}

function sendError(res, err) {
  const status = err.status || 500;
  const body = {
    error: err.code || err.message || 'INTERNAL_ERROR',
    message: err.message
  };
  if (err.errors) body.errors = err.errors;
  if (err.current) body.current = err.current;
  send(res, status, body);
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  return JSON.parse(raw);
}

async function readMultipart(req) {
  // Minimal multipart parser for single file field "file"
  const contentType = req.headers['content-type'] || '';
  const boundaryMatch = contentType.match(/boundary=(.+)$/);
  if (!boundaryMatch) throw Object.assign(new Error('Not multipart'), { status: 400 });

  const boundary = boundaryMatch[1];
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const buffer = Buffer.concat(chunks);
  const parts = buffer.toString('binary').split(`--${boundary}`);

  let file = null;
  for (const part of parts) {
    if (!part.includes('Content-Disposition')) continue;
    const nameMatch = part.match(/name="([^"]+)"/);
    const filenameMatch = part.match(/filename="([^"]+)"/);
    if (!filenameMatch) continue;

    const headerEnd = part.indexOf('\r\n\r\n');
    if (headerEnd === -1) continue;
    const body = part.slice(headerEnd + 4, part.lastIndexOf('\r\n'));
    const mimeMatch = part.match(/Content-Type:\s*(.+)/i);
    file = {
      filename: filenameMatch[1],
      mimeType: mimeMatch ? mimeMatch[1].trim() : 'application/octet-stream',
      buffer: Buffer.from(body, 'binary')
    };
    break;
  }
  if (!file) throw Object.assign(new Error('No file found'), { status: 400 });
  return file;
}

function parseQuery(url) {
  const q = {};
  for (const [k, v] of url.searchParams) {
    if (k === 'filter') {
      if (!q.filters) q.filters = [];
      q.filters.push(v);
    } else {
      q[k] = v;
    }
  }
  return q;
}

// ---------- seed demo schema ----------
function seed() {
  try {
    const existing = getLatestPublished('tech_onboarding');
    if (existing) return;

    const demoSchema = {
      formId: 'tech_onboarding',
      title: '技术岗入职信息表',
      description: '技术岗位入职信息收集',
      version: 1,
      fields: [
        {
          key: 'fullName',
          label: '姓名',
          type: 'input',
          dataType: 'string',
          required: true,
          placeholder: '请输入真实姓名',
          validation: { minLength: 2, maxLength: 50 }
        },
        {
          key: 'email',
          label: '邮箱',
          type: 'input',
          dataType: 'email',
          required: true,
          validation: { format: 'email' }
        },
        {
          key: 'github',
          label: 'GitHub 链接',
          type: 'input',
          dataType: 'string',
          required: false,
          placeholder: 'https://github.com/username'
        },
        {
          key: 'isFreshGraduate',
          label: '是否应届生',
          type: 'select',
          dataType: 'boolean',
          required: true,
          options: [
            { label: '是', value: true },
            { label: '否', value: false }
          ],
          defaultValue: false
        },
        {
          key: 'previousCompany',
          label: '前公司名称',
          type: 'input',
          dataType: 'string',
          required: true,
          visibleWhen: { field: 'isFreshGraduate', operator: 'eq', value: false },
          requiredWhen: { field: 'isFreshGraduate', operator: 'eq', value: false }
        },
        {
          key: 'expectedSalary',
          label: '期望薪资',
          type: 'input',
          dataType: 'number',
          required: true,
          validation: { min: 0, max: 500000 }
        },
        {
          key: 'needHrbpApproval',
          label: '需要 HRBP 特别审批',
          type: 'alert',
          dataType: 'null',
          visibleWhen: { field: 'expectedSalary', operator: 'gt', value: 30000 },
          ui: { variant: 'warning', message: '期望薪资超过 30000，需要 HRBP 特别审批' }
        },
        {
          key: 'workExperience',
          label: '工作履历',
          type: 'repeater',
          dataType: 'array',
          minItems: 0,
          maxItems: 10,
          itemSchema: {
            type: 'object',
            fields: [
              { key: 'company', label: '公司名称', type: 'input', required: true },
              { key: 'position', label: '职位', type: 'input', required: true },
              { key: 'startDate', label: '开始时间', type: 'input', dataType: 'date', required: true },
              { key: 'endDate', label: '结束时间', type: 'input', dataType: 'date' }
            ]
          }
        },
        {
          key: 'resume',
          label: '简历',
          type: 'upload',
          dataType: 'file',
          required: false,
          accept: ['.pdf', '.doc', '.docx'],
          maxSizeMB: 10
        },
        {
          key: 'department',
          label: '部门',
          type: 'select',
          dataType: 'string',
          required: true,
          options: [
            { label: '研发部', value: 'rd' },
            { label: '产品部', value: 'product' },
            { label: '设计部', value: 'design' }
          ]
        }
      ],
      rules: [
        {
          id: 'salary_alert',
          when: { field: 'expectedSalary', operator: 'gt', value: 30000 },
          actions: [
            { type: 'setMessage', target: 'needHrbpApproval', value: '需要 HRBP 特别审批' }
          ]
        }
      ]
    };

    createOrUpdateDraft('tech_onboarding', {
      title: demoSchema.title,
      description: demoSchema.description,
      fields: demoSchema.fields,
      rules: demoSchema.rules
    }, 'system');
    publish('tech_onboarding', 'system');
    console.log('[Seed] demo form tech_onboarding published (v1)');
  } catch (e) {
    console.error('[Seed] failed', e.message);
  }
}

// ---------- router ----------
const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, If-Match, X-Actor',
      'Access-Control-Max-Age': '86400'
    });
    return res.end();
  }

  const url = new URL(req.url || '/', `http://${req.headers.host}`);
  const pathname = url.pathname;
  const method = req.method;
  const actor = req.headers['x-actor'] || 'anonymous';

  try {
    // Health
    if (method === 'GET' && pathname === '/health') {
      return send(res, 200, { status: 'ok', time: new Date().toISOString() });
    }

    // ---------- Schema APIs ----------
    // GET /api/v1/schemas/:formId  → latest published
    let m;
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const schema = getLatestPublished(formId);
      if (!schema) return send(res, 404, { error: 'NOT_FOUND', message: 'No published schema' });
      return send(res, 200, schema);
    }

    // GET /api/v1/schemas/:formId/versions
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)\/versions$/))) {
      const formId = decodeURIComponent(m[1]);
      return send(res, 200, { versions: listVersions(formId) });
    }

    // GET /api/v1/schemas/:formId/versions/:v
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)\/versions\/(\d+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const version = Number(m[2]);
      const schema = getSchemaByVersion(formId, version);
      if (!schema) return send(res, 404, { error: 'NOT_FOUND' });
      return send(res, 200, schema);
    }

    // POST /api/v1/schemas  create draft  body: { formId, title, fields, rules, expectedVersion? }
    if (method === 'POST' && pathname === '/api/v1/schemas') {
      const body = await readJson(req);
      if (!body.formId) return send(res, 400, { error: 'formId required' });
      const result = createOrUpdateDraft(body.formId, body, actor);
      return send(res, 201, result);
    }

    // PUT /api/v1/schemas/:formId  update draft (optimistic lock via expectedVersion or If-Match)
    if (method === 'PUT' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const body = await readJson(req);
      const expectedVersion = body.expectedVersion ?? (req.headers['if-match'] ? Number(req.headers['if-match']) : undefined);
      try {
        const result = createOrUpdateDraft(formId, { ...body, expectedVersion }, actor);
        return send(res, 200, result);
      } catch (e) {
        if (e.code === 'VERSION_CONFLICT') {
          return send(res, 409, {
            error: 'VERSION_CONFLICT',
            message: 'Schema has been modified by another user. Please reload.',
            current: e.current
          });
        }
        throw e;
      }
    }

    // POST /api/v1/schemas/:formId/publish
    if (method === 'POST' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)\/publish$/))) {
      const formId = decodeURIComponent(m[1]);
      try {
        const result = publish(formId, actor);
        return send(res, 200, result);
      } catch (e) {
        if (e.code === 'NO_DRAFT') return send(res, 400, { error: 'NO_DRAFT', message: 'No draft to publish' });
        throw e;
      }
    }

    // GET /api/v1/schemas/:formId/audit
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/schemas\/([^/]+)\/audit$/))) {
      const formId = decodeURIComponent(m[1]);
      return send(res, 200, { logs: getAuditLogs('schema', formId) });
    }

    // ---------- Dynamic Data APIs ----------
    // POST /api/v1/dynamic-data/:formId
    if (method === 'POST' && (m = pathname.match(/^\/api\/v1\/dynamic-data\/([^/]+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const body = await readJson(req);
      try {
        const result = await createSubmission(formId, body, actor);
        return send(res, 201, result);
      } catch (e) {
        if (e.code === 'VALIDATION_FAILED') {
          return send(res, 400, { error: 'VALIDATION_FAILED', message: '数据校验失败', errors: e.errors });
        }
        if (e.code === 'FORM_NOT_FOUND') return send(res, 404, { error: e.code, message: e.message });
        throw e;
      }
    }

    // GET /api/v1/dynamic-data/:formId
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/dynamic-data\/([^/]+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const q = parseQuery(url);
      const result = querySubmissions(formId, {
        page: q.page,
        pageSize: q.pageSize,
        filters: q.filters || [],
        sort: q.sort
      });
      return send(res, 200, result);
    }

    // GET /api/v1/dynamic-data/:formId/:id
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/dynamic-data\/([^/]+)\/(\d+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const id = Number(m[2]);
      const item = getSubmission(formId, id);
      if (!item) return send(res, 404, { error: 'NOT_FOUND' });
      return send(res, 200, item);
    }

    // PATCH /api/v1/dynamic-data/:formId/:id
    if (method === 'PATCH' && (m = pathname.match(/^\/api\/v1\/dynamic-data\/([^/]+)\/(\d+)$/))) {
      const formId = decodeURIComponent(m[1]);
      const id = Number(m[2]);
      const body = await readJson(req);
      try {
        const result = await updateSubmission(formId, id, body, actor);
        return send(res, 200, result);
      } catch (e) {
        if (e.code === 'VALIDATION_FAILED') {
          return send(res, 400, { error: 'VALIDATION_FAILED', errors: e.errors });
        }
        if (e.status === 404) return send(res, 404, { error: 'NOT_FOUND' });
        throw e;
      }
    }

    // GET audit for submission
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/dynamic-data\/([^/]+)\/(\d+)\/audit$/))) {
      const id = m[2];
      return send(res, 200, { logs: getAuditLogs('submission', id) });
    }

    // ---------- File APIs ----------
    // POST /api/v1/files/upload
    if (method === 'POST' && pathname === '/api/v1/files/upload') {
      const file = await readMultipart(req);
      const meta = saveUploadedFile({
        buffer: file.buffer,
        filename: file.filename,
        mimeType: file.mimeType,
        uploadedBy: actor
      });
      return send(res, 201, meta);
    }

    // GET /api/v1/files/:id  meta
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/files\/([^/]+)$/))) {
      const meta = getFileMeta(m[1]);
      if (!meta) return send(res, 404, { error: 'NOT_FOUND' });
      return send(res, 200, meta);
    }

    // GET /api/v1/files/:id/download
    if (method === 'GET' && (m = pathname.match(/^\/api\/v1\/files\/([^/]+)\/download$/))) {
      const info = getFilePath(m[1]);
      if (!info || !fs.existsSync(info.storage_path)) return send(res, 404, { error: 'NOT_FOUND' });
      const data = fs.readFileSync(info.storage_path);
      res.writeHead(200, {
        'Content-Type': info.mime_type || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(info.original_name)}"`,
        'Access-Control-Allow-Origin': '*'
      });
      return res.end(data);
    }

    // Static frontend
    const frontendPublic = path.join(__dirname, '..', '..', 'frontend', 'public');
    if (method === 'GET') {
      let filePath = path.join(frontendPublic, pathname === '/' ? 'index.html' : pathname);
      // prevent path traversal
      if (!filePath.startsWith(frontendPublic)) {
        return send(res, 403, { error: 'FORBIDDEN' });
      }
      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        const ext = path.extname(filePath);
        const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
        res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
        return res.end(fs.readFileSync(filePath));
      }
      // SPA fallback
      const index = path.join(frontendPublic, 'index.html');
      if (fs.existsSync(index) && !pathname.startsWith('/api')) {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        return res.end(fs.readFileSync(index));
      }
    }

    send(res, 404, { error: 'NOT_FOUND', path: pathname });
  } catch (err) {
    console.error(err);
    sendError(res, err);
  }
});

seed();
server.listen(PORT, () => {
  console.log(`HR Dynamic Form API running at http://localhost:${PORT}`);
  console.log(`Health: http://localhost:${PORT}/health`);
  console.log(`Demo schema: GET /api/v1/schemas/tech_onboarding`);
});
