import db, { nowISO } from './db.js';
import { getLatestPublished, getSchemaByVersion } from './schemaService.js';
import { validateAgainstSchema } from './validator.js';
import { runHooks } from './hooks.js';

/**
 * POST /api/v1/dynamic-data/:formId
 * Validate against latest published schema, then persist.
 * Submission always stores the schema_version used at submit time.
 */
export async function createSubmission(formId, payload, actor = 'anonymous') {
  const schemaRecord = getLatestPublished(formId);
  if (!schemaRecord) {
    const err = new Error(`Form "${formId}" has no published schema`);
    err.code = 'FORM_NOT_FOUND';
    err.status = 404;
    throw err;
  }

  const schema = schemaRecord.schema;
  const ctx = {
    formId,
    schemaVersion: schemaRecord.version,
    payload,
    action: 'create',
    actor,
    meta: {}
  };

  await runHooks('beforeValidate', ctx);

  const result = validateAgainstSchema(schema, payload);
  ctx.validation = result;

  await runHooks('afterValidate', ctx);

  if (!result.valid) {
    const err = new Error('VALIDATION_FAILED');
    err.code = 'VALIDATION_FAILED';
    err.status = 400;
    err.errors = result.errors;
    throw err;
  }

  await runHooks('beforeSave', ctx);

  const info = db.prepare(`
    INSERT INTO submissions (form_id, schema_version, data_json, status, created_by, created_at, updated_at)
    VALUES (?, ?, ?, 'submitted', ?, ?, ?)
  `).run(
    formId,
    schemaRecord.version,
    JSON.stringify(payload),
    actor,
    nowISO(),
    nowISO()
  );

  const submissionId = Number(info.lastInsertRowid);
  ctx.submissionId = submissionId;

  // audit
  db.prepare(`
    INSERT INTO audit_logs (entity_type, entity_id, action, actor, after_json, created_at)
    VALUES ('submission', ?, 'create', ?, ?, ?)
  `).run(String(submissionId), actor, JSON.stringify(payload), nowISO());

  await runHooks('afterSave', ctx);

  return {
    id: submissionId,
    formId,
    schemaVersion: schemaRecord.version,
    data: payload,
    meta: ctx.meta,
    createdAt: nowISO()
  };
}

/**
 * Dynamic query with JSON field filters + pagination
 * Query params example:
 *   ?page=1&pageSize=20
 *   &filter=experience>3
 *   &filter=expectedSalary>=30000
 *   &filter=isFreshGraduate=true
 *   &sort=created_at:desc
 */
export function querySubmissions(formId, { page = 1, pageSize = 20, filters = [], sort } = {}) {
  // Base
  let sql = `SELECT id, form_id, schema_version, data_json, status, created_by, created_at, updated_at
             FROM submissions WHERE form_id = ?`;
  const params = [formId];

  // Simple filter parsing: field op value  (op: = > >= < <= !=)
  // We use SQLite json_extract
  for (const f of filters) {
    const m = String(f).match(/^([a-zA-Z0-9_.]+)(>=|<=|!=|>|<|=)(.+)$/);
    if (!m) continue;
    const [, field, op, rawVal] = m;
    let val = rawVal.trim();
    // try number / boolean
    if (val === 'true') val = 1;
    else if (val === 'false') val = 0;
    else if (!Number.isNaN(Number(val)) && val !== '') val = Number(val);
    else val = String(val).replace(/^["']|["']$/g, '');

    const jsonPath = '$.' + field.replace(/\./g, '.');
    // SQLite json_extract returns text; for numbers we cast
    if (typeof val === 'number') {
      sql += ` AND CAST(json_extract(data_json, ?) AS REAL) ${op} ?`;
      params.push(jsonPath, val);
    } else {
      sql += ` AND json_extract(data_json, ?) ${op} ?`;
      params.push(jsonPath, val);
    }
  }

  // count (copy params before pagination is added)
  const countSql = `SELECT COUNT(*) as cnt FROM submissions WHERE form_id = ?` +
    sql.slice(sql.indexOf('WHERE form_id = ?') + 'WHERE form_id = ?'.length);
  const total = db.prepare(countSql).get(...params)?.cnt || 0;

  // sort
  if (sort) {
    const [col, dir] = sort.split(':');
    const allowed = ['created_at', 'updated_at', 'id'];
    if (allowed.includes(col)) {
      sql += ` ORDER BY ${col} ${dir?.toLowerCase() === 'asc' ? 'ASC' : 'DESC'}`;
    }
  } else {
    sql += ` ORDER BY id DESC`;
  }

  // pagination
  const limit = Math.min(Math.max(1, Number(pageSize) || 20), 100);
  const offset = (Math.max(1, Number(page) || 1) - 1) * limit;
  sql += ` LIMIT ? OFFSET ?`;
  params.push(limit, offset);

  const rows = db.prepare(sql).all(...params);

  return {
    total,
    page: Number(page) || 1,
    pageSize: limit,
    items: rows.map(r => ({
      id: r.id,
      formId: r.form_id,
      schemaVersion: r.schema_version,
      data: JSON.parse(r.data_json),
      status: r.status,
      createdBy: r.created_by,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    }))
  };
}

export function getSubmission(formId, id) {
  const row = db.prepare(`
    SELECT * FROM submissions WHERE form_id = ? AND id = ?
  `).get(formId, id);
  if (!row) return null;
  return {
    id: row.id,
    formId: row.form_id,
    schemaVersion: row.schema_version,
    data: JSON.parse(row.data_json),
    status: row.status,
    createdBy: row.created_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

/**
 * PATCH update with field-level audit
 */
export async function updateSubmission(formId, id, patch, actor = 'hr') {
  const existing = getSubmission(formId, id);
  if (!existing) {
    const err = new Error('NOT_FOUND');
    err.status = 404;
    throw err;
  }

  // use the original schema version for validation of new data
  const schemaRecord = getSchemaByVersion(formId, existing.schemaVersion);
  if (!schemaRecord) {
    const err = new Error('SCHEMA_VERSION_MISSING');
    err.status = 500;
    throw err;
  }

  const newData = { ...existing.data, ...patch };
  const result = validateAgainstSchema(schemaRecord.schema, newData);
  if (!result.valid) {
    const err = new Error('VALIDATION_FAILED');
    err.code = 'VALIDATION_FAILED';
    err.status = 400;
    err.errors = result.errors;
    throw err;
  }

  // compute field-level diff for audit
  const diff = {};
  for (const key of new Set([...Object.keys(existing.data), ...Object.keys(newData)])) {
    if (JSON.stringify(existing.data[key]) !== JSON.stringify(newData[key])) {
      diff[key] = { from: existing.data[key], to: newData[key] };
    }
  }

  db.prepare(`
    UPDATE submissions SET data_json = ?, updated_at = ? WHERE id = ?
  `).run(JSON.stringify(newData), nowISO(), id);

  db.prepare(`
    INSERT INTO audit_logs (entity_type, entity_id, action, actor, before_json, after_json, diff_json, created_at)
    VALUES ('submission', ?, 'update', ?, ?, ?, ?, ?)
  `).run(
    String(id),
    actor,
    JSON.stringify(existing.data),
    JSON.stringify(newData),
    JSON.stringify(diff),
    nowISO()
  );

  return getSubmission(formId, id);
}
