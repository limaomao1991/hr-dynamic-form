/**
 * Schema-driven JSON validator + Rule Engine
 * Supports nested object / array (repeater), conditional required/visible,
 * and prevents infinite rule loops.
 */

function getByPath(obj, path) {
  if (!path) return obj;
  const parts = path.split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function evalCondition(condition, data) {
  if (!condition) return true;
  const { field, operator, value } = condition;
  const actual = getByPath(data, field);

  switch (operator) {
    case 'eq': return actual === value;
    case 'neq': return actual !== value;
    case 'gt': return Number(actual) > Number(value);
    case 'gte': return Number(actual) >= Number(value);
    case 'lt': return Number(actual) < Number(value);
    case 'lte': return Number(actual) <= Number(value);
    case 'in': return Array.isArray(value) && value.includes(actual);
    case 'empty': return actual == null || actual === '' || (Array.isArray(actual) && actual.length === 0);
    case 'notEmpty': return !(actual == null || actual === '' || (Array.isArray(actual) && actual.length === 0));
    default: return true;
  }
}

function isFieldVisible(field, data) {
  if (field.deprecated) return false;
  if (!field.visibleWhen) return true;
  return evalCondition(field.visibleWhen, data);
}

function isFieldRequired(field, data) {
  if (field.requiredWhen) {
    return evalCondition(field.requiredWhen, data);
  }
  return !!field.required;
}

function validateValue(field, value, path, errors, data) {
  const fullPath = path ? `${path}.${field.key}` : field.key;

  if (!isFieldVisible(field, data)) {
    return; // skip validation for hidden fields
  }

  const required = isFieldRequired(field, data);

  if (required && (value === undefined || value === null || value === '')) {
    errors.push({ path: fullPath, message: `${field.label || field.key} 是必填项`, code: 'required' });
    return;
  }

  if (value === undefined || value === null || value === '') return;

  const v = field.validation || {};

  if (field.dataType === 'email' || v.format === 'email') {
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(String(value))) {
      errors.push({ path: fullPath, message: `${field.label || field.key} 邮箱格式不正确`, code: 'email' });
    }
  }

  if (field.dataType === 'number' || typeof value === 'number') {
    const num = Number(value);
    if (Number.isNaN(num)) {
      errors.push({ path: fullPath, message: `${field.label || field.key} 必须是数字`, code: 'type' });
    } else {
      if (v.min != null && num < v.min) {
        errors.push({ path: fullPath, message: `${field.label || field.key} 不能小于 ${v.min}`, code: 'min' });
      }
      if (v.max != null && num > v.max) {
        errors.push({ path: fullPath, message: `${field.label || field.key} 不能大于 ${v.max}`, code: 'max' });
      }
    }
  }

  if (typeof value === 'string') {
    if (v.minLength != null && value.length < v.minLength) {
      errors.push({ path: fullPath, message: `${field.label || field.key} 长度不能少于 ${v.minLength}`, code: 'minLength' });
    }
    if (v.maxLength != null && value.length > v.maxLength) {
      errors.push({ path: fullPath, message: `${field.label || field.key} 长度不能超过 ${v.maxLength}`, code: 'maxLength' });
    }
    if (v.pattern) {
      try {
        const re = new RegExp(v.pattern);
        if (!re.test(value)) {
          errors.push({ path: fullPath, message: `${field.label || field.key} 格式不正确`, code: 'pattern' });
        }
      } catch (_) {}
    }
  }

  if (field.type === 'upload' || field.dataType === 'file') {
    // value should be { fileId, name?, size? } or string fileId
    const fileId = typeof value === 'string' ? value : value?.fileId;
    if (required && !fileId) {
      errors.push({ path: fullPath, message: `${field.label || field.key} 需要上传文件`, code: 'required' });
    }
  }
}

function validateFields(fields, data, path, errors) {
  if (!Array.isArray(fields)) return;

  for (const field of fields) {
    if (field.deprecated) continue;

    const value = data ? data[field.key] : undefined;
    const fullPath = path ? `${path}.${field.key}` : field.key;

    if (field.type === 'object' && field.fields) {
      if (value && typeof value === 'object') {
        validateFields(field.fields, value, fullPath, errors);
      } else if (isFieldRequired(field, data)) {
        errors.push({ path: fullPath, message: `${field.label || field.key} 是必填对象`, code: 'required' });
      }
      continue;
    }

    if (field.type === 'repeater' && field.itemSchema) {
      if (!Array.isArray(value)) {
        if (isFieldRequired(field, data) || (field.minItems != null && field.minItems > 0)) {
          errors.push({ path: fullPath, message: `${field.label || field.key} 必须是数组`, code: 'type' });
        }
        continue;
      }
      if (field.minItems != null && value.length < field.minItems) {
        errors.push({ path: fullPath, message: `${field.label || field.key} 至少需要 ${field.minItems} 项`, code: 'minItems' });
      }
      if (field.maxItems != null && value.length > field.maxItems) {
        errors.push({ path: fullPath, message: `${field.label || field.key} 最多允许 ${field.maxItems} 项`, code: 'maxItems' });
      }
      const itemFields = field.itemSchema.fields || field.itemSchema;
      value.forEach((item, idx) => {
        validateFields(itemFields, item, `${fullPath}[${idx}]`, errors);
      });
      continue;
    }

    if (field.type === 'alert') continue; // display only

    validateValue(field, value, path, errors, data);
  }
}

/**
 * Main validate entry
 * @returns {{ valid: boolean, errors: Array<{path, message, code}> }}
 */
export function validateAgainstSchema(schema, payload) {
  const errors = [];
  const fields = schema.fields || [];
  validateFields(fields, payload || {}, '', errors);
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Rule Engine with cycle protection
 * Rules can modify form state (set value, show/hide, set message)
 * Max iterations and visited set prevent A→B→C→A loops
 */
export function runRuleEngine(schema, formState, maxIterations = 20) {
  const rules = schema.rules || [];
  if (rules.length === 0) return { state: formState, messages: {}, executed: [] };

  let state = { ...formState };
  const messages = {};
  const executed = [];
  const visited = new Set();

  let iteration = 0;
  let changed = true;

  while (changed && iteration < maxIterations) {
    changed = false;
    iteration++;

    for (const rule of rules) {
      const ruleKey = `${rule.id || JSON.stringify(rule)}@${iteration}`;
      if (visited.has(ruleKey)) continue;

      const when = rule.when;
      if (!evalCondition(when, state)) continue;

      visited.add(ruleKey);
      executed.push(rule.id || ruleKey);

      for (const action of rule.actions || []) {
        if (action.type === 'setValue' && action.target) {
          const old = state[action.target];
          if (old !== action.value) {
            state[action.target] = action.value;
            changed = true;
          }
        }
        if (action.type === 'setMessage' && action.target) {
          messages[action.target] = action.value;
        }
        // show/hide are handled by visibleWhen on fields, not mutating state
      }
    }
  }

  if (iteration >= maxIterations) {
    console.warn('[RuleEngine] max iterations reached, possible cycle detected');
  }

  return { state, messages, executed, iterations: iteration };
}

export { evalCondition, isFieldVisible, isFieldRequired, getByPath };
