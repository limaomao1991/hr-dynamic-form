/**
 * Lifecycle hooks / plugin system (Q4)
 *
 * Hook points:
 *   beforeValidate | afterValidate | beforeSave | afterSave | onError
 */

const plugins = [];

export function registerPlugin(plugin) {
  if (!plugin?.name || !plugin.hooks) {
    throw new Error('Invalid plugin');
  }
  plugins.push(plugin);
  console.log(`[Plugin] registered: ${plugin.name}`);
}

export async function runHooks(point, ctx) {
  for (const plugin of plugins) {
    const fn = plugin.hooks[point];
    if (typeof fn === 'function') {
      try {
        await fn(ctx);
      } catch (err) {
        console.error(`[Plugin:${plugin.name}] ${point} error:`, err.message);
        if (point !== 'onError') {
          // allow onError handlers to run
          await runHooks('onError', { ...ctx, error: err, failedHook: point, plugin: plugin.name });
        }
        throw err;
      }
    }
  }
}

// ---------- Built-in example plugins ----------

registerPlugin({
  name: 'dingtalk-notifier',
  hooks: {
    afterSave: async (ctx) => {
      if (ctx.action !== 'create' && ctx.action !== 'submit') return;
      // Mock: in real world call DingTalk webhook
      console.log(`[DingTalk] 新入职表单提交通知 formId=${ctx.formId} submissionId=${ctx.submissionId}`);
      ctx.meta = ctx.meta || {};
      ctx.meta.dingtalkNotified = true;
    }
  }
});

registerPlugin({
  name: 'pdf-contract-generator',
  hooks: {
    afterSave: async (ctx) => {
      if (ctx.action !== 'create') return;
      // Mock PDF generation
      console.log(`[PDF] 已为 submission ${ctx.submissionId} 生成合同 PDF (mock)`);
      ctx.meta = ctx.meta || {};
      ctx.meta.pdfGenerated = true;
      ctx.meta.pdfUrl = `/api/v1/files/mock-contract-${ctx.submissionId}.pdf`;
    }
  }
});

registerPlugin({
  name: 'attendance-sync',
  hooks: {
    afterSave: async (ctx) => {
      if (ctx.action !== 'create') return;
      console.log(`[Attendance] 候选人已同步至第三方考勤系统 submission=${ctx.submissionId}`);
      ctx.meta = ctx.meta || {};
      ctx.meta.attendanceSynced = true;
    }
  }
});
