import db, { nowISO } from './db.js';

/**
 * Schema lifecycle:
 * - Create as draft (version = max+1 or 1)
 * - Edit only draft
 * - Publish → status=published, published_at set, previous published becomes archived
 * - Historical submissions always reference the exact schema_version they used
 */

export function getLatestPublished(formId) {
  const row = db.prepare(`
    SELECT * FROM schemas
    WHERE form_id = ? AND status = 'published'
    ORDER BY version DESC LIMIT 1
  `).get(formId);
  if (!row) return null;
  return hydrate(row);
}

export function getSchemaByVersion(formId, version) {
  const row = db.prepare(`
    SELECT * FROM schemas WHERE form_id = ? AND version = ?
  `).get(formId, version);
  if (!row) return null;
  return hydrate(row);
}

export function listVersions(formId) {
  return db.prepare(`
    SELECT id, form_id, version, status, title, created_at, published_at, updated_at
    FROM schemas WHERE form_id = ? ORDER BY version DESC
  `).all(formId);
}

export function getDraft(formId) {
  const row = db.prepare(`
    SELECT * FROM schemas WHERE form_id = ? AND status = 'draft'
    ORDER BY version DESC LIMIT 1
  `).get(formId);
  return row ? hydrate(row) : null;
}

function hydrate(row) {
  return {
    id: row.id,
    formId: row.form_id,
    version: row.version,
    status: row.status,
    title: row.title,
    description: row.description,
    schema: JSON.parse(row.schema_json),
    createdBy: row.created_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at
  };
}

/**
 * Create new form (first version as draft) or new draft based on latest
 */
export function createOrUpdateDraft(formId, { title, description, fields, rules, expectedVersion }, actor = 'hr') {
  const latest = db.prepare(`
    SELECT * FROM schemas WHERE form_id = ? ORDER BY version DESC LIMIT 1
  `).get(formId);

  // Optimistic locking: if client sent expectedVersion, check it
  if (expectedVersion != null && latest && latest.version !== expectedVersion) {
    const err = new Error('VERSION_CONFLICT');
    err.code = 'VERSION_CONFLICT';
    err.current = hydrate(latest);
    throw err;
  }

  let version;
  let existingDraft = getDraft(formId);

  if (existingDraft) {
    // update existing draft
    version = existingDraft.version;
    const schemaJson = JSON.stringify({
      formId,
      title: title || existingDraft.title,
      description: description ?? existingDraft.description,
      version,
      fields: fields || existingDraft.schema.fields,
      rules: rules || existingDraft.schema.rules || []
    });

    db.prepare(`
      UPDATE schemas SET title = ?, description = ?, schema_json = ?, updated_at = ?, created_by = ?
      WHERE form_id = ? AND version = ? AND status = 'draft'
    `).run(
      title || existingDraft.title,
      description ?? existingDraft.description,
      schemaJson,
      nowISO(),
      actor,
      formId,
      version
    );

    writeAudit('schema', `${formId}@${version}`, 'update_draft', actor, existingDraft.schema, JSON.parse(schemaJson));
    return getSchemaByVersion(formId, version);
  }

  // new version as draft
  version = latest ? latest.version + 1 : 1;
  const schemaObj = {
    formId,
    title: title || formId,
    description: description || '',
    version,
    fields: fields || [],
    rules: rules || []
  };

  db.prepare(`
    INSERT INTO schemas (form_id, version, status, title, description, schema_json, created_by, created_at, updated_at)
    VALUES (?, ?, 'draft', ?, ?, ?, ?, ?, ?)
  `).run(
    formId,
    version,
    schemaObj.title,
    schemaObj.description,
    JSON.stringify(schemaObj),
    actor,
    nowISO(),
    nowISO()
  );

  writeAudit('schema', `${formId}@${version}`, 'create_draft', actor, null, schemaObj);
  return getSchemaByVersion(formId, version);
}

/**
 * Publish current draft → becomes the new published version.
 * Previous published versions are marked archived (keep history).
 */
export function publish(formId, actor = 'hr') {
  const draft = getDraft(formId);
  if (!draft) {
    const err = new Error('NO_DRAFT');
    err.code = 'NO_DRAFT';
    throw err;
  }

  // archive old published
  db.prepare(`
    UPDATE schemas SET status = 'archived', updated_at = ?
    WHERE form_id = ? AND status = 'published'
  `).run(nowISO(), formId);

  // publish draft
  db.prepare(`
    UPDATE schemas SET status = 'published', published_at = ?, updated_at = ?
    WHERE form_id = ? AND version = ?
  `).run(nowISO(), nowISO(), formId, draft.version);

  writeAudit('schema', `${formId}@${draft.version}`, 'publish', actor, { status: 'draft' }, { status: 'published' });
  return getLatestPublished(formId);
}

function writeAudit(entityType, entityId, action, actor, before, after) {
  let diff = null;
  if (before && after) {
    // simple top-level diff for demo
    diff = {};
    const keys = new Set([...Object.keys(before || {}), ...Object.keys(after || {})]);
    for (const k of keys) {
      if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) {
        diff[k] = { from: before[k], to: after[k] };
      }
    }
  }
  db.prepare(`
    INSERT INTO audit_logs (entity_type, entity_id, action, actor, before_json, after_json, diff_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    entityType,
    entityId,
    action,
    actor,
    before ? JSON.stringify(before) : null,
    after ? JSON.stringify(after) : null,
    diff ? JSON.stringify(diff) : null,
    nowISO()
  );
}

export function getAuditLogs(entityType, entityId, limit = 50) {
  return db.prepare(`
    SELECT * FROM audit_logs
    WHERE entity_type = ? AND entity_id LIKE ?
    ORDER BY id DESC LIMIT ?
  `).all(entityType, `${entityId}%`, limit).map(r => ({
    ...r,
    before: r.before_json ? JSON.parse(r.before_json) : null,
    after: r.after_json ? JSON.parse(r.after_json) : null,
    diff: r.diff_json ? JSON.parse(r.diff_json) : null
  }));
}
