import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import db, { nowISO } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const ALLOWED_MIME = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'image/jpeg',
  'image/png',
  'image/webp'
]);

const MAX_SIZE = 10 * 1024 * 1024; // 10MB

/**
 * Secure file upload (Q3)
 * - Never store binary inside Submission JSON
 * - Store only fileId reference
 * - Validate mime + size
 * - Save to disk (or S3 in production)
 */
export function saveUploadedFile({ buffer, filename, mimeType, uploadedBy }) {
  if (!buffer || buffer.length === 0) {
    const err = new Error('Empty file');
    err.status = 400;
    throw err;
  }
  if (buffer.length > MAX_SIZE) {
    const err = new Error(`File too large (max ${MAX_SIZE / 1024 / 1024}MB)`);
    err.status = 400;
    throw err;
  }
  // basic mime check (can be spoofed; production should use file-type / magic bytes)
  if (mimeType && !ALLOWED_MIME.has(mimeType)) {
    const err = new Error(`MIME type not allowed: ${mimeType}`);
    err.status = 400;
    throw err;
  }

  const id = crypto.randomUUID();
  const hash = crypto.createHash('sha256').update(buffer).digest('hex');
  const ext = path.extname(filename || '') || '';
  const storageName = `${id}${ext}`;
  const storagePath = path.join(UPLOAD_DIR, storageName);

  fs.writeFileSync(storagePath, buffer);

  db.prepare(`
    INSERT INTO files (id, original_name, mime_type, size, storage_path, hash, uploaded_by, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, filename || storageName, mimeType || 'application/octet-stream', buffer.length, storagePath, hash, uploadedBy || null, nowISO());

  return {
    fileId: id,
    name: filename,
    size: buffer.length,
    mimeType,
    hash
  };
}

export function getFileMeta(fileId) {
  const row = db.prepare(`SELECT * FROM files WHERE id = ?`).get(fileId);
  if (!row) return null;
  return {
    fileId: row.id,
    name: row.original_name,
    mimeType: row.mime_type,
    size: row.size,
    hash: row.hash,
    createdAt: row.created_at
  };
}

export function getFilePath(fileId) {
  const row = db.prepare(`SELECT storage_path, mime_type, original_name FROM files WHERE id = ?`).get(fileId);
  if (!row) return null;
  return row;
}
