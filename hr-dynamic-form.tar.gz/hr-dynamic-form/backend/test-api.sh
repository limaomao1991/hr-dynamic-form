#!/bin/bash
set -e
BASE=http://127.0.0.1:3000
echo "=== 1. Health ==="
curl -s $BASE/health | head -c 80; echo

echo "=== 2. Get Schema ==="
curl -s $BASE/api/v1/schemas/tech_onboarding | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['formId'],'v'+str(d['version']),d['title'])"

echo "=== 3. Validation fail ==="
curl -s -X POST $BASE/api/v1/dynamic-data/tech_onboarding -H 'Content-Type: application/json' \
  -d '{"fullName":"A","email":"x"}' | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['error'], len(d.get('errors',[])))"

echo "=== 4. Valid submit ==="
curl -s -X POST $BASE/api/v1/dynamic-data/tech_onboarding -H 'Content-Type: application/json' -H 'X-Actor: tester' \
  -d '{"fullName":"李四","email":"lisi@test.com","isFreshGraduate":true,"expectedSalary":28000,"department":"product"}' \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print('id',d['id'],'hooks',list(d.get('meta',{}).keys()))"

echo "=== 5. Filter query ==="
curl -s "$BASE/api/v1/dynamic-data/tech_onboarding?filter=expectedSalary>30000" \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print('total',d['total'])"

echo "=== 6. Optimistic lock demo ==="
# get current version
VER=$(curl -s $BASE/api/v1/schemas/tech_onboarding/versions | python3 -c "import sys,json;vs=json.load(sys.stdin)['versions'];print(vs[0]['version'] if vs else 1)")
echo "current top version: $VER"
# create draft if needed
curl -s -X PUT $BASE/api/v1/schemas/tech_onboarding -H 'Content-Type: application/json' -H 'X-Actor: A' \
  -d "{\"title\":\"技术岗入职信息表(A)\",\"fields\":[{\"key\":\"fullName\",\"label\":\"姓名\",\"type\":\"input\",\"required\":true}],\"expectedVersion\":$VER}" \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print('A saved',d.get('version'),d.get('status') or d.get('error'))"

# B tries with same expectedVersion → should 409 if A already advanced
curl -s -o /tmp/b.json -w "%{http_code}" -X PUT $BASE/api/v1/schemas/tech_onboarding -H 'Content-Type: application/json' -H 'X-Actor: B' \
  -d "{\"title\":\"技术岗入职信息表(B)\",\"fields\":[{\"key\":\"fullName\",\"label\":\"姓名B\",\"type\":\"input\",\"required\":true}],\"expectedVersion\":$VER}"
echo
cat /tmp/b.json | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('error'), d.get('message','')[:60])"

echo "=== Done ==="
